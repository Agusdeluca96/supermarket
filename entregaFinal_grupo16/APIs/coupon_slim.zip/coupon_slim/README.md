# Desarrollo de Software en Sistemas Distribuidos - Coupon - Capa de Servicios


## **Requisitos**
  * [Slim 3](https://www.slimframework.com/docs/)
  * [PHP](http://php.net/)  (De 5.5.9 en adelante, recomendado > 7)
  * [Composer](https://getcomposer.org)


## **Para correr el proyecto**
1. Clonar el repositorio
	
	`git clone https://github.com/Agusdeluca96/coupon_slim`
2. Situarme en el interior de la carpeta clonada.	
3. Instalar dependencias:

    `composer update`
4. Iniciar el server:

	`composer start`
5. Probar con [Postman](https://www.getpostman.com) o algun programa para hacer solicitudes REST.
