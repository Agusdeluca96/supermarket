<?php
namespace App\Model;

use App\Lib\Database;
use App\Lib\Response;

class CouponModel
{
    private $db;
    private $table = 'coupon';
    private $response;

    public function __CONSTRUCT()
    {
        $this->db = Database::StartUp();
        $this->response = new Response();
    }

    public function getAll()
    {
		try
		{
			$result = array();

			$stm = $this->db->prepare("SELECT * FROM $this->table");
			$stm->execute();

			$this->response->setResponse(true);
            $this->response->result = $stm->fetchAll();

            return $this->response->result;
		}
		catch(Exception $e)
		{
			$this->response->setResponse(false, $e->getMessage());
            return $this->response;
		}
	}
	
	public function getAllUnused()
    {
		try
		{
			$result = array();

			$stm = $this->db->prepare("SELECT * FROM $this->table WHERE used = 0");
			$stm->execute();

			$this->response->setResponse(true);
            $this->response->result = $stm->fetchAll();

            return $this->response->result;
		}
		catch(Exception $e)
		{
			$this->response->setResponse(false, $e->getMessage());
            return $this->response;
		}
    }

    public function get($cod)
    {
		try
		{
			$result = array();

			$stm = $this->db->prepare("SELECT * FROM $this->table WHERE cod = ?");
			$stm->execute(array($cod));

			$this->response->setResponse(true);
            $this->response->result = $stm->fetch();

            return $this->response->result;
		}
		catch(Exception $e)
		{
			$this->response->setResponse(false, $e->getMessage());
            return $this->response;
		}
    }

    public function isValid($cod)
    {
		try
		{
			$result = array();

			$stm = $this->db->prepare("SELECT * FROM $this->table WHERE cod = ?");
			$stm->execute(array($cod));

			$this->response->setResponse(true);
            $this->response->result = $stm->fetch();

            $now = new \Datetime();
            $now = $now->format('Y-m-d h:i:s');

            $coupon = $this->response->result;
            $valid = $coupon->used == 0 && $coupon->valid_from < $now && $coupon->good_thru > $now;

            return ($valid);
		}
		catch(Exception $e)
		{
			$this->response->setResponse(false, $e->getMessage());
            return $this->response;
		}
	}
	
	public function insertOrUpdate($data)
    {
		try
		{
			$cod = $data['cod'];
			$validFrom = new \Datetime($data['valid_from']);
			$goodThru = new \Datetime($data['good_thru']);

            if(isset($data['id']))
            {
				$id = $data['id'];

				$stm = $this->db->prepare("SELECT * FROM $this->table WHERE id = ?");
				$stm->execute([$id]);
				$coupon = $stm->fetch();

				// $coupon = $this->db->prepare("SELECT * FROM $this->table WHERE id = ?")->execute([$id])->fetch();

				if ($coupon != null) {
					$stm = $this->db->prepare("SELECT * FROM $this->table WHERE cod = ? AND id != ?");
					$stm->execute([$cod, $id]);

					$couponSameCod = $stm->fetch();

					if ($couponSameCod == null) {
						$sql = "UPDATE $this->table SET cod = ?, valid_from = ?, good_thru = ? WHERE id = ?";
						$this->db->prepare($sql)->execute([$cod, $validFrom->format('Y-m-d h:i:s'), $goodThru->format('Y-m-d h:i:s'), $id]);
						$this->response->setResponse(true);
						return "Operacion exitosa. El cupon ha sido modificado.";
					} else {
						$this->response->setResponse(false, "Operacion invalida. El codigo de cupon que esta queriendo insertar ya esta siendo utilizado");
						return "Operacion invalida. El codigo de cupon que esta queriendo insertar ya esta siendo utilizado";
					}
				} else {
					$this->response->setResponse(false, "Operacion invalida. No existe ningun cupon con el id ingresado.");
					return "Operacion invalida. No existe ningun cupon con el id ingresado.";
				}
            }
            else
            {
				$stm = $this->db->prepare("SELECT * FROM $this->table WHERE cod = ?");
				$stm->execute([$cod]);

				$couponSameCod = $stm->fetch();

				if ($couponSameCod == null) {
					$sql = "INSERT INTO $this->table (cod, used, valid_from, good_thru) VALUES (?,?,?,?)";
					$this->db->prepare($sql)->execute([$cod, 0, $validFrom->format('Y-m-d h:i:s'), $goodThru->format('Y-m-d h:i:s')]);
					$this->response->setResponse(true);
            		return "Operacion exitosa. El cupon ha sido agregado.";
				} else {
					$this->response->setResponse(false, "Operacion invalida. El codigo de cupon que esta queriendo insertar ya esta siendo utilizado");
					return "Operacion invalida. El codigo de cupon que esta queriendo insertar ya esta siendo utilizado";
				}
            }
		}
		catch (Exception $e)
		{
            $this->response->setResponse(false, $e->getMessage());
		}
	}
	
	public function use($data)
    {
		try
		{
			$cod = $data['cod'];

            $sql = "UPDATE $this->table SET used = ? WHERE cod = ?";
			$this->db->prepare($sql)->execute([1, $cod]);
            
			$this->response->setResponse(true);
            return "Operacion exitosa. El cupon ha sido marcado como usado.";
		}
		catch (Exception $e)
		{
            $this->response->setResponse(false, $e->getMessage());
		}
	}
	
	public function unuse($data)
    {
		try
		{
			$cod = $data['cod'];

            $sql = "UPDATE $this->table SET used = ? WHERE cod = ?";
			$this->db->prepare($sql)->execute([0, $cod]);
            
			$this->response->setResponse(true);
            return "Operacion exitosa. El cupon ha sido marcado como no usado.";
		}
		catch (Exception $e)
		{
            $this->response->setResponse(false, $e->getMessage());
		}
	}
	
	public function unuseAll()
    {
		try
		{
            $sql = "UPDATE $this->table SET used = ?";
			$this->db->prepare($sql)->execute([0]);
            
			$this->response->setResponse(true);
            return "Operacion exitosa. Todos los cupones has sido marcados como no usados.";
		}
		catch (Exception $e)
		{
            $this->response->setResponse(false, $e->getMessage());
		}
	}
	
	public function delete($cod)
    {
		try 
		{
			$sql = "DELETE FROM $this->table WHERE cod = ?";
			$this->db->prepare($sql)->execute([$cod]);			          

            $this->response->setResponse(true);
            return "Operacion exitosa. El cupon ha sido eliminado con exito.";
		} catch (Exception $e) 
		{
			$this->response->setResponse(false, $e->getMessage());
		}
    }

}
