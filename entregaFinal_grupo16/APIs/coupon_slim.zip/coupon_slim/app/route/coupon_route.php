<?php
use App\Model\CouponModel;

$app->group('/coupon/', function () {

    $this->get('', function ($req, $res, $args) {
        $um = new CouponModel();

        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                $um->getAll()
            )
        );
    });

    $this->get('unuseds', function ($req, $res, $args) {
        $um = new CouponModel();

        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                $um->getAllUnused()
            )
        );
    });

    $this->get('{cod}', function ($req, $res, $args) {
        $um = new CouponModel();

        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                $um->get($args['cod'])
            )
        );
    });

    $this->get('{cod}/isValid', function ($req, $res, $args) {
        $um = new CouponModel();

        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                $um->isValid($args['cod'])
            )
        );
    });

    $this->post('', function ($req, $res) {
        $um = new CouponModel();

        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                $um->insertOrUpdate(
                    $req->getParsedBody()
                )
            )
        );
    });

    $this->post('use', function ($req, $res) {
        $um = new CouponModel();

        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                $um->use(
                    $req->getParsedBody()
                )
            )
        );
    });

    $this->post('unuse', function ($req, $res) {
        $um = new CouponModel();

        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                $um->unuse(
                    $req->getParsedBody()
                )
            )
        );
    });

    $this->post('unuseAll', function ($req, $res) {
        $um = new CouponModel();

        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                $um->unuseAll()
            )
        );
    });

    $this->post('delete/{cod}', function ($req, $res, $args) {
        $um = new CouponModel();
        
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                $um->delete($args['cod'])
            )
        );
    });

    $this->get('{cod}/use', function ($req, $res, $args) {
        $um = new CouponModel();

        return $res
            ->withHeader('Content-type', 'application/json')
            ->getBody()
            ->write(
            json_encode(
                $um->use($args)
            )
        );
    });

    $this->get('{cod}/unuse', function ($req, $res, $args) {
        $um = new CouponModel();

        return $res
            ->withHeader('Content-type', 'application/json')
            ->getBody()
            ->write(
            json_encode(
                $um->unuse($args)
            )
        );
    });


});
