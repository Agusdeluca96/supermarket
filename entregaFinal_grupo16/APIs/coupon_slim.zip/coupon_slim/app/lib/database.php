<?php
namespace App\Lib;

use PDO;

class Database
{
    public static function StartUp()
    {
        $pdo = new PDO('pgsql:host=ec2-54-221-234-62.compute-1.amazonaws.com;port=5432;dbname=dfngbjaiohvq0h;user=djombzecpchiui;password=b1bf606c1ba52fc4279cd40de651f6f267a6fff2d429a4b7ad6d69cdcd067748');        
        // $pdo = new PDO('mysql:host=localhost;dbname=coupon;charset=utf8', 'root', '');
        
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
        
        return $pdo;
    }
}