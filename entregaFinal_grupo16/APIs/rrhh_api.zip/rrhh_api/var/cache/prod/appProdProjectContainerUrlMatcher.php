<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($rawPathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request ?: $this->createRequest($pathinfo);
        $requestMethod = $canonicalMethod = $context->getMethod();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }

        if (0 === strpos($pathinfo, '/employee')) {
            // app_employee_addemployee
            if ('/employee' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\EmployeeController::addEmployee',  '_route' => 'app_employee_addemployee',);
                if (!in_array($requestMethod, array('POST'))) {
                    $allow = array_merge($allow, array('POST'));
                    goto not_app_employee_addemployee;
                }

                return $ret;
            }
            not_app_employee_addemployee:

            // app_employee_getemployees
            if ('/employee' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\EmployeeController::getEmployees',  '_route' => 'app_employee_getemployees',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_app_employee_getemployees;
                }

                return $ret;
            }
            not_app_employee_getemployees:

            // app_employee_findemployeebyemail
            if ('/employee/find' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\EmployeeController::findEmployeeByEmail',  '_route' => 'app_employee_findemployeebyemail',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_app_employee_findemployeebyemail;
                }

                return $ret;
            }
            not_app_employee_findemployeebyemail:

            // app_employee_verifyemployeebyid
            if ('/employee/isValid' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\EmployeeController::verifyEmployeeById',  '_route' => 'app_employee_verifyemployeebyid',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_app_employee_verifyemployeebyid;
                }

                return $ret;
            }
            not_app_employee_verifyemployeebyid:

            // app_employee_getemployee
            if (preg_match('#^/employee/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_employee_getemployee')), array (  '_controller' => 'AppBundle\\Controller\\EmployeeController::getEmployee',));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_app_employee_getemployee;
                }

                return $ret;
            }
            not_app_employee_getemployee:

            if (0 === strpos($pathinfo, '/employeeType')) {
                // app_employeetype_addemployeetype
                if ('/employeeType' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\EmployeeTypeController::addEmployeeType',  '_route' => 'app_employeetype_addemployeetype',);
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_app_employeetype_addemployeetype;
                    }

                    return $ret;
                }
                not_app_employeetype_addemployeetype:

                // app_employeetype_getemployeetypes
                if ('/employeeType' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\EmployeeTypeController::getEmployeeTypes',  '_route' => 'app_employeetype_getemployeetypes',);
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_app_employeetype_getemployeetypes;
                    }

                    return $ret;
                }
                not_app_employeetype_getemployeetypes:

                // app_employeetype_getemployeetype
                if (preg_match('#^/employeeType/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_employeetype_getemployeetype')), array (  '_controller' => 'AppBundle\\Controller\\EmployeeTypeController::getEmployeeType',));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_app_employeetype_getemployeetype;
                    }

                    return $ret;
                }
                not_app_employeetype_getemployeetype:

            }

        }

        if ('/' === $pathinfo && !$allow) {
            throw new Symfony\Component\Routing\Exception\NoConfigurationException();
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
