# Desarrollo de Software en Sistemas Distribuidos - RRHH - Capa de Servicios

## **PHP**
  * [Symfony 3.4](https://symfony.com/doc/3.4/index.html)
  * [JMSSerializerBundle](http://jmsyst.com/bundles/JMSSerializerBundle)
  * [FOSRestBundle](https://symfony.com/doc/master/bundles/FOSRestBundle/index.html)
  * [NelmioCorsBundle](https://github.com/nelmio/NelmioCorsBundle)
## **REST**

### **FOSRestBundle**

  * Se recomienda heredar los Controller de `RestBundle\Controller\RestController`
  * Este a su vez hereda del `FOS\RestBundle\Controller\FOSRestController`
  * Incorpora extensiones mediante traits para implementar funcionalidad comun (ver `extensiones`) en este documento
  * También provee dos metodos útiles:
    * `getEntityManager()`: Devuelve el EntityManager de Doctrine. Es equivalente a `$this->getDoctrine()->getManager()`
    * `getRepository(ClaseEntity)`: Devuelve el repositorio para una entidad. Es equivalente a `$em->getRepository()`
  * La ventaja de usar estos metodos es que nos ahorramos la variable temporal para el `Entity Manager`. Ademas, tienen en la documentacion de la funcion el tipo de retorno: `@return \Doctrine\ORM\EntityRepository`; esto permite a los IDE listar los metodos de los repositorios, el autocompletado, etc
  * Tener un Controller base puede permitir a futuro agregar funcionalidad que sea comun a todos

## **Extensiones**

  * [Traits](http://php.net/manual/en/language.oop5.traits.php) que se pueden incorporar a cualquier clase, para proveer funcionalidad adicional
  * A diferencia de la herencia, no obligan a heredar de una clase (a veces no se puede); simplemente se incluyen metodos a una clase

### **HttpExceptionsTrait**

Este trait tiene metodos para lanzar las excepciones HTTP más comunes de manera mas sencilla:

  * `createBadRequestException($message)`: Lanza una `BadRequestHttpException` con el mensaje indicado. El codigo HTTP de esta excepcion es 400

## **Requisitos**
  1. Proyecto Symfony 3.4, por lo tanto requiere php >= 5.5.9 (recomendado php >= 7)
  2. [composer](https://getcomposer.org)

## **Para correr el proyecto**
1. Instalar dependencias:
    * `composer install`
2. Correr el proyecto:
    * Con el server embebido de Symfony: `php bin/console server:run`
    * Apache:
      * Guardar el proyecto se guarda en un subdirectorio de `htdocs`
3. Probar con [Postman](https://www.getpostman.com) o algun programa para hacer solicitudes REST.