<?php

namespace AppBundle\Entity;

class EmployeeValidity
{
    private $isValid;

    public function __construct($isValid) {
        $this->isValid = $isValid;
    }

    /**
     * Set isValid
     *
     * @param boolean $isValid
     *
     */
    public function setIsValid($isValid)
    {
        $this->isValid = $isValid;

        return $this;
    }

    /**
     * Get isValid
     *
     * @return boolean
     */
    public function getIsValid()
    {
        return $this->isValid;
    }

}
