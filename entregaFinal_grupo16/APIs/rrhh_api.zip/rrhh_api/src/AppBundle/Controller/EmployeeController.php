<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use FOS\RestBundle\Controller\Annotations\Get;
use FOS\RestBundle\Controller\Annotations\Post;
use FOS\RestBundle\Controller\Annotations\Patch;
use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\RequestParam;
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\Request\ParamFetcher;
use FOS\RestBundle\View\View;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Routing\Annotation\Route;
use AppBundle\Entity\Employee;
use AppBundle\Entity\EmployeeType;
use AppBundle\Entity\EmployeeValidity;


/**
* @Route("/employee")
*/
class EmployeeController extends RestController
{

    /**
    * Da de alta un empleado y retorna la entidad creada.
    *
    * @Post("")
    *
    * @RequestParam(name="firstname", allowBlank=false, strict=true, nullable=false, description="Nombre del empleado")
    * @RequestParam(name="surname", allowBlank=false, strict=true, nullable=false, description="Apellido del empleado")
    * @RequestParam(name="email", allowBlank=false, strict=true, nullable=false, description="Email del empleado")
    * @RequestParam(name="password", allowBlank=false, strict=false, nullable=true, description="Contraseña del empleado")
    * @RequestParam(name="employee_type_id", requirements={"rule"="^\d+$", "error_message"="El ID del tipo de empleado debe ser un entero"}, allowBlank=false, strict=true, nullable=false, description="ID del tipo de empleado")
    *
    * @param ParamFetcher $paramFetcher
    *
    * @return View
    */
    public function addEmployee(ParamFetcher $paramFetcher)
    {
        $firstname = trim($paramFetcher->get('firstname'));
        $surname = trim($paramFetcher->get('surname'));
        $email = trim($paramFetcher->get('email'));
        $password = trim($paramFetcher->get('password'));
        $employeeType = $this->findEmployeeTypeByIdOrFail(trim($paramFetcher->get('employee_type_id')));

        if (empty($password)) {
            $password = null;
        }

        $employee = new Employee($firstname, $surname, $email, $password, $employeeType);
        $em = $this->getEntityManager();
        $em->persist($employee);
        $em->flush();

        return $this->returnJSONView(Response::HTTP_OK, $employee);
    }

    /**
    * Recupera todos los empleados.
    *
    * @Get("")
    *
    * @return View
    *
    */
    public function getEmployees()
    {
        $employees = $this->getRepository(Employee::class)->findAll();

        return $this->returnJSONView(Response::HTTP_OK, $employees);
    }

    /**
    * Busca un empleado por email y password y devuelve si las credenciales son válidas.
    *
    * @Get("/find")
    *
    * @QueryParam(name="email", allowBlank=false, strict=true, nullable=false, description="Email del empleado")
    *
    * @param ParamFetcher $paramFetcher
    *
    * @return View
    *
    */
    public function findEmployeeByEmail(ParamFetcher $paramFetcher)
    {
        $email = $paramFetcher->get('email');
        $employee = $this->getRepository(Employee::class)->findOneBy(['email' => $email]);

        if(empty($employee)) {
            return $this->returnJSONView(Response::HTTP_NO_CONTENT, []);
        }

        return $this->returnJSONView(Response::HTTP_OK, $employee);
    }

    /**
    * Recupera el empleado con el id enviado en la url.
    *
    * @Get("/isValid")
    *
    * @QueryParam(name="id", allowBlank=false, strict=true, nullable=false, description="Id del empleado")
    *
    * @param ParamFetcher $paramFetcher
    *
    * @return View
    *
    */
    public function verifyEmployeeById(ParamFetcher $paramFetcher)
    {
        $id = $paramFetcher->get('id');
        $employee = $this->getRepository(Employee::class)->find($id);

        if(empty($employee)) {
            $result = new EmployeeValidity(false);
        } else {
            $result = new EmployeeValidity(true);
        }

        return $this->returnJSONView(Response::HTTP_OK, $result);
    }

    /**
    * Recupera el empleado con el id enviado en la url.
    *
    * @Get("/{id}")
    *
    * @return View
    *
    */
    public function getEmployee(Employee $employee)
    {
        return $this->returnJSONView(Response::HTTP_OK, $employee);
    }



    /**
    * Busca un EmployeeType por id. Podria devolver null
    *
    * @param string $id
    *
    * @return \AppBundle\Entity\EmployeeType
    */
    protected function findEmployeeTypeById(string $id)
    {
        return $this->getRepository(EmployeeType::class)->find($id);
    }

    /**
    * Busca un EmployeeType por id; levanta una excepcion 400 Bad Request si el EmployeeType no existe
    *
    * @param string $id
    *
    * @return \AppBundle\Entity\EmployeeType
    */
    protected function findEmployeeTypeByIdOrFail(string $id)
    {
        $employeeType = $this->findEmployeeTypeById($id);
        if (empty($employeeType)) {
            $this->createBadRequestException('Tipo de empleado inexistente');
        }

        return $employeeType;
    }
}
