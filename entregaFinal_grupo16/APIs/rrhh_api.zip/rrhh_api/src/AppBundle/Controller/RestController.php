<?php

namespace AppBundle\Controller;

use AppBundle\Extensions\HttpExceptionsTrait;
use AppBundle\Extensions\RepositoryExtensionsTrait;
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\Request\ParamFetcher;
use FOS\RestBundle\View\View;

abstract class RestController extends FOSRestController
{
    // Para usar la extension del manejo de errores
    // use HttpExceptionsTrait, RepositoryExtensionsTrait;

    /**
     * Devuelve el EntityManager de Doctrine
     *
     * @return \Doctrine\ORM\EntityManager
     */
    protected function getEntityManager()
    {
        return $this->getDoctrine()->getManager();
    }

    /**
     * Devuelve el repositorio para una entidad
     *
     * @param string $entityName El nombre la entidad
     *
     * @return \Doctrine\ORM\EntityRepository
     */
    protected function getRepository($entityName)
    {
        return $this->getEntityManager()->getRepository($entityName);
    }

    /**
     * Retorna una respuesta HTTP, con codigo $status y y los datos del parametro $data serializados a JSON
     *
     * @param int   $status    codigo HTTP de la respuesta
     * @param mixed $data      objeto a serializar y retornar
     *
     * @return \FOS\RestBundle\View\View
     */
    protected function returnJSONView($status, $data)
    {
        $view = View::create();
        $view->setStatusCode($status)->setData($data);

        return $view;
    }
}
