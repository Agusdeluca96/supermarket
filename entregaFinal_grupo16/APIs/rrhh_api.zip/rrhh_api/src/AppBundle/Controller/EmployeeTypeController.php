<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use FOS\RestBundle\Controller\Annotations\Get;
use FOS\RestBundle\Controller\Annotations\Post;
use FOS\RestBundle\Controller\Annotations\Patch;
use FOS\RestBundle\Controller\Annotations\QuertParam;
use FOS\RestBundle\Controller\Annotations\RequestParam;
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\Request\ParamFetcher;
use FOS\RestBundle\View\View;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Routing\Annotation\Route;
use AppBundle\Entity\EmployeeType;


/**
* @Route("/employeeType")
*/
class EmployeeTypeController extends RestController
{
    
    /**
    * Da de alta un tipo de empleado y retorna la entidad creada.
    *
    * @Post("")
    *
    * @RequestParam(name="initials", allowBlank=false, strict=true, nullable=false, description="Iniciales del tipo de empleado")
    * @RequestParam(name="description", allowBlank=false, strict=true, nullable=false, description="Descripcion del tipo de empleado")
    *
    * @param ParamFetcher $paramFetcher
    *
    * @return View
    */
    public function addEmployeeType(ParamFetcher $paramFetcher)
    {
        $initials = trim($paramFetcher->get('initials'));
        $description = trim($paramFetcher->get('description'));

        $employeeType = new EmployeeType($initials, $description);
        $em = $this->getEntityManager();
        $em->persist($employeeType);
        $em->flush();

        return $this->returnJSONView(Response::HTTP_OK, $employeeType);
    }

    /**
    * Recupera todos los tipos de empleado.
    *
    * @Get("")
    *
    * @return View
    *
     */
    public function getEmployeeTypes()
    {
        $employeeTypes = $this->getRepository(EmployeeType::class)->findAll();

        return $this->returnJSONView(Response::HTTP_OK, $employeeTypes);
    }

    /**
    * Recupera el tipo de empleado con el id enviado en la url.
    *
    * @Get("/{id}")
    *
    * @return View
    *
    */
    public function getEmployeeType(EmployeeType $employeeType)
    {
        return $this->returnJSONView(Response::HTTP_OK, $employeeType);
    }
}
