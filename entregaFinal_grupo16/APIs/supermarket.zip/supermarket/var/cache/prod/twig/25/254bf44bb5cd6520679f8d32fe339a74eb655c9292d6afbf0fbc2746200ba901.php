<?php

/* default/index.html.twig */
class __TwigTemplate_14e7f7dafa5169005f2c63b97bcbd73176078cf39d41a28e705dc54ddcdec191 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'main' => array($this, 'block_main'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_stylesheets($context, array $blocks = array())
    {
        echo " 
    ";
        // line 3
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/index.css"), "html", null, true);
        echo "\"> 
";
    }

    // line 6
    public function block_main($context, array $blocks = array())
    {
        // line 7
        echo "    <nav class=\"navbar navbar-expand-md navbar-dark fixed-top bg-dark\">
        <a class=\"navbar-brand\" href=\"#\">Super Market</a>
        <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarCollapse\" aria-controls=\"navbarCollapse\"
            aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            <span class=\"navbar-toggler-icon\"></span>
        </button>
        <div class=\"collapse navbar-collapse\" id=\"navbarCollapse\">
            <ul class=\"navbar-nav mr-auto\">
            </ul>
            ";
        // line 16
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_EMPLOYEE")) {
            // line 17
            echo "            <a class=\"btn btn-outline-danger\" href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("logout");
            echo "\">Cerrar Sesion</a>
            ";
        } else {
            // line 19
            echo "            <a class=\"btn btn-outline-success\" href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
            echo "\">Iniciar Sesion</a>
            ";
        }
        // line 21
        echo "        </div>
    </nav>

    <div class=\"container\">
        <div class=\"album py-5\">
            <div class=\"row\">
                ";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["products"] ?? null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 28
            echo "                <div class=\"col-md-4\">
                    <div class=\"card mb-4 shadow-sm\">
                        <img class=\"card-img-top productImg\" src=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(twig_get_attribute($this->env, $this->source, $context["product"], "img_url", array())), "html", null, true);
            echo "\" data-holder-rendered=\"true\">
                        <div class=\"card-body\">
                            <p class=\"card-text\">";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["product"], "name", array()), "html", null, true);
            echo "</p>
                            <div class=\"d-flex justify-content-between align-items-center\">
                                <div class=\"btn-group\">
                                    ";
            // line 35
            if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_EMPLOYEE")) {
                // line 36
                echo "                                    <a class=\"btn btn-sm btn-outline-primary\" href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("buy", array("product" => twig_get_attribute($this->env, $this->source, $context["product"], "id", array()), "coupon" => "0")), "html", null, true);
                echo "\">Comprar
                                        <i class=\"fas fa-shopping-cart\"></i>
                                    </a>
                                    ";
            } else {
                // line 40
                echo "                                    ";
                $this->loadTemplate("default/modal_coupon.html.twig", "default/index.html.twig", 40)->display($context);
                // line 41
                echo "                                    <button type=\"button\" class=\"btn btn-sm btn-outline-primary buttonComprar\" data-toggle=\"modal\" data-target=\"#exampleModalCenter\" href=\"\" id=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["product"], "id", array()), "html", null, true);
                echo "\" id>Comprar
                                        <i class=\"fas fa-shopping-cart\"></i>
                                    </button>
                                    ";
            }
            // line 45
            echo "                                </div>
                                <ul class=\"priceAndStock\">
                                    <li>
                                        <small class=\"text-muted\"><b>Stock:</b> ";
            // line 48
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["product"], "quantity", array()), "html", null, true);
            echo "</small>
                                    </li>
                                    <li>
                                        <small class=\"text-muted\"><b>Precio lista:</b> \$";
            // line 51
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["product"], "sale_price", array()), "html", null, true);
            echo "</small>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 59
        echo "            </div>
        </div>
    </div>
";
    }

    // line 63
    public function block_javascripts($context, array $blocks = array())
    {
        echo " 
    ";
        // line 64
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"";
        // line 65
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/js/index.js"), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  187 => 65,  183 => 64,  178 => 63,  171 => 59,  149 => 51,  143 => 48,  138 => 45,  130 => 41,  127 => 40,  119 => 36,  117 => 35,  111 => 32,  106 => 30,  102 => 28,  85 => 27,  77 => 21,  71 => 19,  65 => 17,  63 => 16,  52 => 7,  49 => 6,  43 => 4,  39 => 3,  34 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "default/index.html.twig", "/Applications/XAMPP/xamppfiles/htdocs/supermarket/app/Resources/views/default/index.html.twig");
    }
}
