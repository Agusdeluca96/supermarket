<?php

/* default/login.html.twig */
class __TwigTemplate_c1725a39670be43c991de6eafa328c9ec0ec5fe39c40513cfd69d8870b8ac471 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/login.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 3
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/login.css"), "html", null, true);
        echo "\">
";
    }

    // line 6
    public function block_main($context, array $blocks = array())
    {
        // line 7
        echo "    <body class=\"text-center\">
        <form action=\"";
        // line 8
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        echo "\" method=\"post\" class=\"form-signin\">
            <img class=\"mb-4\" src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/images/uploads/image_login.png"), "html", null, true);
        echo "\" alt=\"Login\" width=\"72\" height=\"72\">
            <h1 class=\"h3 mb-3 font-weight-normal\">Iniciar Sesión</h1>

            ";
        // line 12
        if (($context["error"] ?? null)) {
            // line 13
            echo "            <div class=\"alert alert-danger\" role=\"alert\">
                Usuario o contraseña invalida.
            </div>
            ";
        }
        // line 17
        echo "            <label for=\"inputEmail\" class=\"sr-only\">Correo electrónico</label>
            <input name=\"_username\" type=\"email\" id=\"inputEmail\" class=\"form-control\" placeholder=\"Correo electrónico\" required=\"\" autofocus=\"\" value=\"";
        // line 18
        echo twig_escape_filter($this->env, ($context["last_username"] ?? null), "html", null, true);
        echo "\">
            <label for=\"inputPassword\" class=\"sr-only\">Contraseña</label>
            <input name=\"_password\" type=\"password\" id=\"inputPassword\" class=\"form-control\" placeholder=\"Contraseña\" required=\"\">
            <br>
            <input type=\"hidden\" name=\"_target_path\" value=\"/\" />
            <button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\">Ingresar</button>
            <p class=\"mt-5 mb-3 text-muted\">© Grupo 16 - Sistemas Distribuidos</p>
        </form>
    </body>
";
    }

    public function getTemplateName()
    {
        return "default/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 18,  71 => 17,  65 => 13,  63 => 12,  57 => 9,  53 => 8,  50 => 7,  47 => 6,  41 => 4,  36 => 3,  33 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "default/login.html.twig", "/Applications/XAMPP/xamppfiles/htdocs/supermarket/app/Resources/views/default/login.html.twig");
    }
}
